function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	return destroyItem(player, target, toPosition)
end

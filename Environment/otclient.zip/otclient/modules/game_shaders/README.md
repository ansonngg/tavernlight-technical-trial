# game_shaders

This module is based on [mehah/otclient](https://github.com/mehah/otclient). I have removed all the unused parts to make the solution cleaner, and modified some parts to make it work with edubart/otclient's API and fit my requirement.

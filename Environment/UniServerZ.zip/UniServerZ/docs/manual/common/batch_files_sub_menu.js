document.write('<span class=\"sub_menu_header\">Batch files</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p1910\"><a href=\"batch_files_passing_parameters.html\"  target=\"_top\"   >Batch files - Passing parameters</a></li>');
document.write('<li class=\"p1920\"><a href=\"batch_files_emulate_server_console.html\"  target=\"_top\"   >Batch file - Emulate server console</a></li>');


document.write('</ul>');
document.write('</div>');

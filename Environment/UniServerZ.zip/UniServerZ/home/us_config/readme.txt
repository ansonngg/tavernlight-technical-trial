###############################################################################
# File name: readme.txt
# Created By: The Uniform Server Development Team
###############################################################################

 Folder UniServerZ\home\us_config is a repository for the following two files: 
  .htaccess and  favicon.ico
 These files are copied to each new Vhost created.

 Folder UniServerZ\home\us_config also contains general server configuration
 information in file us_config.ini, user configuration information in file
 us_user.ini, and logs clean-up configuration information in file us_clean_up.ini

